package com.example.ecoapp

data class User(val name: String? = null, val email: String? =null, val pass: String? = null, val municipio: String? = null)
