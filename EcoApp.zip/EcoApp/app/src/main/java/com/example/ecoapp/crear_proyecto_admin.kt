package com.example.ecoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class crear_proyecto_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_proyecto_admin)
    }
}